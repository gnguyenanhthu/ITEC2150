package ca6.p1;
import java.util.Scanner;
public class ExceptionDemo3 {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        int x = input.nextInt();
        int y = input.nextInt();
        System.out.println("x = " + x );
        System.out.println("y = " + y);

    }
}
